"""
This is my quant toolbox.
"""
print("Welcome to hchyt quant box!")